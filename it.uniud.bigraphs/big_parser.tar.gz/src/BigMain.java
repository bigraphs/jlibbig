import java.io.*;
import java.util.*;

import jlibbig.*;

public class BigMain{
	public static void main(String[] args) throws Exception{
			
		BigraphParser parser = new BigraphParser();
		System.out.print("inizio parsing...\n");
		parser.parseString( "%active c : 2; c[x:e,y:e].(c[z:e , w:o]);\n" );
		System.out.print("fine\n");
		
	}
	private static BigraphBuilder printBB(BigraphBuilder b){
		return printBB("Builder",b);
	}
	private static BigraphBuilder printBB(String prefix, BigraphBuilder b){
		System.out.println(prefix + ": " + b.getNodes() + " " + b.getEdges() + " " + b.getInnerFace() + " -> " + b.getOuterFace());
		return b;
	}
	
	private static Bigraph printBig(Bigraph b){
		return printBig("Bigraph", b);
	}

	private static Bigraph printBig(String prefix, Bigraph b){
		System.out.println(prefix + ": " + b.getNodes() + " " + b.getEdges() + " " + b.getInnerFace() + " -> " + b.getOuterFace());
		return b;
	}
	
}