package jlibbig;

public class Root implements PlaceGraphFacet, PlaceGraph.Parent{
	
}
