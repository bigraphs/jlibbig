package jlibbig;

public class NameOverlapException extends Exception {
	private static final long serialVersionUID = 7906403825825798881L;
}
