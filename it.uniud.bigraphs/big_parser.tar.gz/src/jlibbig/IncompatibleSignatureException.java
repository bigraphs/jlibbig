package jlibbig;

public class IncompatibleSignatureException extends Exception{

	private static final long serialVersionUID = -2623617487911027928L;

	public IncompatibleSignatureException() {
		// TODO Auto-generated constructor stub
	}

}
