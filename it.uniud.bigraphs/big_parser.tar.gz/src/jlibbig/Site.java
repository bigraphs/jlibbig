package jlibbig;

public class Site implements  PlaceGraphFacet, PlaceGraph.Child {

}
