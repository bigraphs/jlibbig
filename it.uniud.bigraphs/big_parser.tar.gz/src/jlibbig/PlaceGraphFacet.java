package jlibbig;

interface PlaceGraphFacet {

}
