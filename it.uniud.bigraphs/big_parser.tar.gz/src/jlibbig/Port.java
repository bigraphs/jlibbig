package jlibbig;

public interface Port extends LinkGraph.Linked{
	public LinkGraphNode getNode();
	public int getNumber();
}
